const express = require('express');
const router = express.Router();

const {
    updatePost

}= require('./controller');

router.put("/", updatePost)


module.exports = router