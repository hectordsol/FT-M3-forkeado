let data = require('../data')

const STATUS_USER_ERROR = 422;

const updatePost = (req, res) => {
    const { id, title, contents } = req.body;
  
    if (!id || !title || !contents) {
      return res.status(STATUS_USER_ERROR).json({
        error:
          "No se recibieron los parámetros necesarios para modificar el Post",
      });
    }
  
    // const idFilter = posts.filter((post) => post.id === id);
    const post = data.posts.find((post) => post.id === id);
  
    if (!post) {
      return res.status(STATUS_USER_ERROR).json({
        error: "Su post no se encuentra en los registros",
      });
    }
  
    // si uso filter tengo que modificar el array original
  
    // posts.forEach(post => {
    //   if(post.id === id){
    //     post.title = title;
    //     post.contents = contents;
    //   }
    // })
  
    post.title = title;
    post.contents = contents;
  
    res.json(post);
  };

module.exports = {
    updatePost
}