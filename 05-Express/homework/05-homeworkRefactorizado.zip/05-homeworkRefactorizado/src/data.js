let posts = [];

module.exports = { posts}