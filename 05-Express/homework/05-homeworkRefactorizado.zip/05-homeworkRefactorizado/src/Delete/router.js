const express = require('express');
const router = express.Router();

const {
    updatePost, deleteById, deleteByAuthor

}= require('./controller');

router.delete("/posts", deleteById)
router.delete('/author', deleteByAuthor)


module.exports = router