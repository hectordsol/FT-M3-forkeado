let data = require('../data')

const STATUS_USER_ERROR = 422;

deleteById = (req, res) => {
    const { id } = req.body;
  
    if (!id) {
      return res.status(STATUS_USER_ERROR).json({ error: "Debe ingresar un id" });
    }
    const post = data.posts.find((post) => post.id === id);
  
    if (!post) {
      return res.status(STATUS_USER_ERROR).json({
        error: "El post que quiere eliminar no se encuentra en los registros",
      });
    }

    const idDelete = data.posts.filter((post) => post.id !== id);
    data.posts = idDelete;

    res.json({ success: true });
}  

deleteByAuthor = (req, res) => {
    const { author } = req.body;
  
    if (!author) {
      return res.status(STATUS_USER_ERROR).json({
        error: "Debe ingresar un autor",
      });
    }
  
    const authorFilter = data.posts.filter((post) => post.author === author);
  
    if (!authorFilter.length) {
      return res.status(STATUS_USER_ERROR).json({
        error: "No existe el autor indicado",
      });
    }
  
    const newPosts = data.posts.filter((post) => post.author !== author);
  
    data.posts = newPosts;
  
    res.json(authorFilter);
  };



module.exports = {
    deleteById, 
    deleteByAuthor
}