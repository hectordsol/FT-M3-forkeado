const express = require('express');
const router = express.Router();

const {
    createPost,
    createOtro

}= require('./controller');

router.post("/", createPost)

router.post('/author/:author', createOtro);

module.exports = router
