
let data = require('../data')
var id = 0;
const STATUS_USER_ERROR = 422;

const createPost = (req, res) => {
    const { author, title, contents } = req.body;
  
    if (!author || !title || !contents) {
      return res.status(STATUS_USER_ERROR).json({
        error: "No se recibieron los parámetros necesarios para crear el Post",
      });
    }
    let post = {
      id: ++id,
      author,
      title,
      contents,
    };
  
    data.posts.push(post);
    // return res.status(200).json(post)
    res.json(post); //el json ya devuelve una respuesta
    //   next();
  };
  
  const createOtro = (req, res) => {
    const author = req.params.author;
    const { title, contents } = req.body;
    if (!title || !contents) {
      return res.status(STATUS_USER_ERROR).json({
        error: "No se recibieron los parámetros necesarios para crear el Post",
      });
    }
    let post = {
      id: ++id,
      author,
      title,
      contents,
    };
    data.posts.push(post);
    res.json(post);
  };
  
  module.exports = {
      createPost,
      createOtro
  }
