let data = require('../data')



const STATUS_USER_ERROR = 422;


const getAll = (req, res) => {
    const { term } = req.query;
    const termFilter = data.posts.filter(
        (post) => post.title.includes(term) || post.contents.includes(term)
      );
    if (termFilter.length > 0) {
      
      return res.json(termFilter);
    }if(termFilter === 0) {
        return res
          .status(STATUS_USER_ERROR)
          .json({ error: "No existe ningun post del autor indicado" });
    }else{
        res.json(data.posts);
    }
  
    
  }

const getByAuthor =  (req, res) => {
    const author = req.params.author;
    const authorFilter = data.posts.filter((post) => post.author === author);
  
    if (authorFilter.length === 0) {
      return res
        .status(STATUS_USER_ERROR)
        .json({ error: "No existe ningun post del autor indicado" });
    }
  
    res.json(authorFilter);
  };

  const getByTitle = (req, res) => {
    const { author, title } = req.params;
    const authorFilter = data.posts.filter(
      (post) => post.author === author && post.title === title
    );
  
    if (authorFilter.length === 0) {
      return res.status(STATUS_USER_ERROR).json({
        error: "No existe ningun post con dicho titulo y autor indicado",
      });
    }
  
    res.json(authorFilter);
  };
  


module.exports = {
    getAll,
    getByAuthor, 
    getByTitle
}