const express = require('express');
const router = express.Router();

const {
    
    getAll,
    getByAuthor,
    getByTitle

}= require('./controller');

router.get("/", getAll)

router.get("/:author", getByAuthor)

router.get("/:author/:title", getByTitle)


module.exports = router